﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreadingResultApp
{
    class Grade
    {
        public string gradeName;
        public double averageMark;
        public double physic;
        public double camistry;
        public double math;

        public string GetGrade(double gradeMarks)
        {
            if (physic < 50 || camistry < 50 || math < 50)
            {
                gradeName = "F";
            }
            else
            {
                if (averageMark > 100 || averageMark < 0)
                {
                    return "Invalid number";
                }

                if (gradeMarks >= 80)
                {
                    gradeName = "A+";
                }


                else if (gradeMarks >= 70)
                {
                    gradeName = "B+";
                }
                else if (gradeMarks > 60)
                {
                    gradeName = "C+";
                }
                else if (gradeMarks > 50)
                {
                    gradeName = "D+";
                }
                else if (gradeMarks > 40)
                {
                    gradeName = "E+";
                }
                else
                {
                    gradeName = "F";
                }
            }
            return gradeName;
        }

        public double GetAverage(double physic,double camistry,double math)
        {

            return (physic+camistry+math)/3;
        }
        
    }


}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GreadingResultApp
{
    public partial class Form1 : Form
    {
        Grade aGrade=new Grade();
        public Form1()
        {
            InitializeComponent();
        }
        //public double Validation()
        //{
        //    if (string.IsNullOrEmpty(physicTextBox.Text))
        //    {
        //        MessageBox.Show("Plese enter the number");
                
        //    }
        //    return false
        //}
        private void showButton_Click(object sender, EventArgs e)
        {
            
            aGrade.physic = Convert.ToDouble(physicTextBox.Text);
            aGrade.camistry = Convert.ToDouble(cmistrytextBox.Text);
            aGrade.math = Convert.ToDouble(mathTextBox.Text);
            string msg = aGrade.GetAverage(aGrade.physic, aGrade.camistry, aGrade.math).ToString();

            MessageBox.Show(msg);
            averageTextBox.Text = msg;
            double grade = Convert.ToDouble(aGrade.GetAverage(aGrade.physic, aGrade.camistry, aGrade.math));
            gradeTaxtBox.Text = aGrade.GetGrade(grade);
        }

        
    }
}

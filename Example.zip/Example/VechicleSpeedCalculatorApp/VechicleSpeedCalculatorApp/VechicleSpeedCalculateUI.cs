﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VechicleSpeedCalculatorApp
{
    public partial class VechicleSpeedCalculateUI : Form
    {
        private Vechicle aVechicle = new Vechicle();

        public VechicleSpeedCalculateUI()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(vechicleNametextBox.Text))
                {
                    MessageBox.Show("Please enter the Vechile Name");
                    return;
                    
                }
                aVechicle.vechicleName = vechicleNametextBox.Text;
                aVechicle.registrationNumber = regNoTextbox.Text;
                MessageBox.Show("Successfully Created");
            }
            catch
            {
                MessageBox.Show("Something missing");

            }
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(speedTextBox.Text))
            {
                MessageBox.Show("Please enter the Vechile Name");
                return;

            }
            double speed = Convert.ToDouble(speedTextBox.Text);
            aVechicle.setSpeed(speed);
        }

        private void showSpeedButton_Click(object sender, EventArgs e)
        {
            double minSpeed = aVechicle.GetminSpeed();
            double maxSpeed = aVechicle.GetMaxSpeed();
           // double average = aVechicle.GetAverageSpeed();
            minSpeedTextBox.Text = minSpeed.ToString();
            maxSpeedTextBox.Text=maxSpeed.ToString();
        }
    }
}

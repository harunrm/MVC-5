﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VechicleSpeedCalculatorApp
{
    class Vechicle
    {
        public string vechicleName;
        public string registrationNumber;
        public double minSpeed = 0;
        public double maxSpeed=0;
        public double averageSpeed = 0;
        public double someOfSpeed = 0;
        public double numOfspeed = 0;
        public double speed=0;
        public void setSpeed(double speed)
        {
            if (numOfspeed == 0)
            {
                minSpeed = speed;
                maxSpeed = speed;
            }
            else
            {
                if (speed < minSpeed)
                {
                    minSpeed = speed;
                }
                if (speed > maxSpeed)
                {
                    maxSpeed = speed;
                }
            }
            numOfspeed++;

        }
        public double GetminSpeed()
        {
            if (speed > minSpeed)
            {
                minSpeed = speed;
            }
            return minSpeed;
        }
        
        public double GetMaxSpeed()
        {
            if (speed > maxSpeed)
            {
                minSpeed = speed;
            }
            return maxSpeed;
        }

        //public double GetAverageSpeed()
        //{
        //    return;
        //}
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountOperationApp
{
    class Account
    {
        private string accountNumber;
        private string accountName;
        public double balance=0;

        //public string Deposit(double amount)
        //{
        //    balance += amount;
        //    return balance;
        //}
        public void SetNumber(string newAccountNumber)
        {
            accountName = newAccountNumber;
        }

        public string GetAccount()
        {
            return accountNumber;
        }
        public string Deposit(double amount)
        {
            balance += amount;
            return "Deposited taka  " + balance;

        }
        public string Withdraw(double amount)
        {
            balance -= amount;
            return "Deposited taka  " + balance;

        }
    }
}

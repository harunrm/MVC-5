﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccountOperationApp
{
    public partial class AccountOperationUI : Form
    {
        Account anAccount=new Account();
        public AccountOperationUI()
        {
            InitializeComponent();
        }

        private void withdrowButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(amountTextBox.Text))
            {
                MessageBox.Show("please enter amount");
                return;
            }
            double amount = Convert.ToDouble(amountTextBox.Text);
            string msg = anAccount.Withdraw(amount);
            MessageBox.Show(msg);
            amountTextBox.Text = "";
        }

        private void depositButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(amountTextBox.Text))
            {
                MessageBox.Show("please enter amount");
                return;
            }
            double amount = Convert.ToDouble(amountTextBox.Text);
            string msg = anAccount.Deposit(amount);
            MessageBox.Show(msg);
            amountTextBox.Text = "";

        }

        public void Empty()
        {
            
        }
    }
}

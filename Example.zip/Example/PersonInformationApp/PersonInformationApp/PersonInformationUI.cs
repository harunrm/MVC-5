﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonInformationApp
{
    public partial class PersonInformationUI : Form
    {
        public PersonInformationUI()
        {
            InitializeComponent();
        }
        Person aPerson=new Person();
        private void showButton_Click(object sender, EventArgs e)
        {
            setName();
            MessageBox.Show(aPerson.GetFullName());

        }

        public void setName()
        {
            aPerson.firstName = firstNameTextBox.Text;
            aPerson.middleName = middleNameTextBox.Text;
            aPerson.lastName = lastNameTextBox.Text;
            
        }


        private void reverseName_Click(object sender, EventArgs e)
        {
            setName();
            MessageBox.Show(aPerson.GetReversName());

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeSalaryInterest
{
    
    public partial class EmployeeSalaryUI : Form
    {
        public EmployeeSalaryUI()
        {
            InitializeComponent();
        }
        List<Employee> employeeList=new List<Employee>(); 
        private void showButton_Click(object sender, EventArgs e)
        {
            Employee employeeObj=new Employee();
            employeeObj.amount = Convert.ToDouble(basicAmountTextBox.Text);
            employeeObj.interest = Convert.ToDouble(interestAmountTextBox.Text);
            employeeObj.year = Convert.ToDouble(timePeriodTextBox.Text);
            employeeList.Add(employeeObj);
            MessageBox.Show(employeeObj.GetTotal().ToString());
            //ListView salaryView=new ListView();
          
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryInterest
{
    class Employee
    {
        public double amount;
        public double interest;
        public double toalInterst;
        public double year;
        public double total;
        public double GetTotal()
        {
            toalInterst=(interest/100)*amount;
            toalInterst = (toalInterst * year) + amount;
            return toalInterst;
        }


    }
}

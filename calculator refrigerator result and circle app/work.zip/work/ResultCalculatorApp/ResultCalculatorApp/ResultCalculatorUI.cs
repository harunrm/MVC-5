﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResultCalculatorApp
{
    public partial class ResultCalculatorUI : Form
    {
        StudentResult aStudentResult = new StudentResult();

        public ResultCalculatorUI()
        {
            InitializeComponent();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            aStudentResult.physicsNumber = Convert.ToDouble(physicsNumberTextBox.Text);
            aStudentResult.chemistryNumber = Convert.ToDouble(chemistryNumberTextBox.Text);
            aStudentResult.mathNumber = Convert.ToDouble(mathNumberTextBox.Text);

            double average = aStudentResult.GetAverage();
            string grade = aStudentResult.GetGrade();

            averageTextBox.Text = average.ToString("0.00");
            gradeTextBox.Text = grade;
        }
    }
}

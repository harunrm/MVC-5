﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ResultCalculatorApp
{
    internal class StudentResult
    {
        public double physicsNumber;
        public double chemistryNumber;
        public double mathNumber;
        private double average;

        public double GetAverage()
        {
            average = (physicsNumber + chemistryNumber + mathNumber)/3;
            return average;
        }

        public string GetGrade()
        {
            if (average >= 80) { return "A+"; }
            if (average >= 70) { return "B+"; }
            if (average >= 60) { return "C+"; }
            if (average >= 50) { return "D+"; }
            return "F";
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefrigeratorApp
{
    class Refrigerator
    {
        public double maxWeight = 0;
        private double currentWeight = 0;
        private double remainingWeight = 0;

        public void AddItems(int noOfItem, double unitWeight)
        {
            if ((noOfItem*unitWeight) > remainingWeight)
            {
                throw new Exception("Wigth will overflown!");
            }

            currentWeight += noOfItem*unitWeight;
        }

        public double GetCurrentWeight()
        {
            return currentWeight;
        }

        public double GetRemainingWeight()
        {
            remainingWeight = maxWeight - currentWeight;
            return remainingWeight;
        }
    }
}

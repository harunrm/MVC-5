﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RefrigeratorApp
{
    public partial class RefrigeratorUI : Form
    {
        private Refrigerator aRefrigerator;

        public RefrigeratorUI()
        {
            InitializeComponent();
        }

        private void capacityButton_Click(object sender, EventArgs e)
        {
            double capacity = Convert.ToDouble(capacityTextBox.Text);
            aRefrigerator = new Refrigerator();
            aRefrigerator.maxWeight = capacity;

            currentWeightTextBox.Text = aRefrigerator.GetCurrentWeight().ToString();
            remainingWeightTextBox.Text = aRefrigerator.GetRemainingWeight().ToString();
        }

        private void addItemButton_Click(object sender, EventArgs e)
        {
            if (aRefrigerator == null)
            {
                MessageBox.Show("Set Capacity first!");
                return;
            }

            int numOfItem = Convert.ToInt32(noOfItemTextBox.Text);
            double unitWeight = Convert.ToDouble(unitWeightTextBox.Text);

            try
            {
                aRefrigerator.AddItems(numOfItem, unitWeight);
                currentWeightTextBox.Text = aRefrigerator.GetCurrentWeight().ToString();
                remainingWeightTextBox.Text = aRefrigerator.GetRemainingWeight().ToString();
            }
            catch (Exception)
            {

                MessageBox.Show("Weight will overflown!");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalaryCalculatorApp
{
    class Employee
    {
        private string name;
        private double basicAmount;
        private double houseRent;
        private double medicalAllowance;
        private double totalSalary;

        public Employee(string employeeName)
        {
            name = employeeName;
        }

        public string GetSalary(string basicAmount, string houseRent, string medicalAllowance)
        {
            try
            {
                this.basicAmount = Convert.ToDouble(basicAmount);
            }
            catch (Exception)
            {

                return "Basic Amount is not a number";
            }

            try
            {
                this.houseRent = Convert.ToDouble(houseRent);
            }
            catch (Exception)
            {

                return "House Rent is not a number";
            }

            try
            {
                this.medicalAllowance = Convert.ToDouble(medicalAllowance);
            }
            catch (Exception)
            {

                return "Medical Allowance is not a number";
            }

            totalSalary = this.basicAmount + (this.houseRent/100)*this.basicAmount +
                          (this.medicalAllowance/100)*this.basicAmount;

            return "Mr. " + name + ", your total salary is: " + totalSalary.ToString();
        }
    }
}

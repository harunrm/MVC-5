﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalaryCalculatorApp
{
    public partial class SalaryCalculatorUI : Form
    {
        public SalaryCalculatorUI()
        {
            InitializeComponent();
        }

        private void calculateSalaryButton_Click(object sender, EventArgs e)
        {
            Employee aEmployee = new Employee(employeeNameTextBox.Text);

            string result = aEmployee.GetSalary(basicAmountTextBox.Text, houseRentTextBox.Text,
                medicalAllowanceTextBox.Text);
            MessageBox.Show(result);
        }
    }
}

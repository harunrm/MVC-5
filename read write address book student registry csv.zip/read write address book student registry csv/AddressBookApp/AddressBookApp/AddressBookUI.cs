﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CSVLib;

namespace AddressBookApp
{
    public partial class AddressBookUI : Form
    {
        private string addressBook = @"addressBook.csv";
        public AddressBookUI()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            //FileStream aFileStream=new FileStream(addressBook,FileMode.Append);
            //CsvFileWriter cavWrite=new CsvFileWriter(aFileStream);
            //List<string> addressList=new List<string>();
            //addressList.Add(nameTextBox.Text);
            //addressList.Add(emailTextBox.Text);
            //addressList.Add(personalContacttextBox.Text);
            //addressList.Add(homeContactTextBox.Text);
            //addressList.Add(addressTextBox.Text);
            //cavWrite.WriteRow(addressList);
            //aFileStream.Close();

        }

        private void showButton_Click(object sender, EventArgs e)
        {
            FileStream aStream = new FileStream(addressBook, FileMode.Open);
            CsvFileReader csvRead = new CsvFileReader(aStream);
            List<string> addressReadList = new List<string>();
            while (csvRead.ReadRow(addressReadList))
            {
                string name = addressReadList[0];
                string email = addressReadList[1];
                string pcontuct = addressReadList[2];
                string hcontact = addressReadList[3];
                string address = addressReadList[4];
                showAllIfolistBox.Items.Add(name + "   " + email + "  " + pcontuct + "  " + address);
                aStream.Close();

            }
        }
    }
}

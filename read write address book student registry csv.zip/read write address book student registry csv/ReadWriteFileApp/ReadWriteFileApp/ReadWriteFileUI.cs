﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadWriteFileApp
{
    public partial class ReadWriteFileUI : Form
    {
        public ReadWriteFileUI()
        {
            InitializeComponent();
        }

        //private string path = Environment.CurrentDirectory + "/" + "studentFile.txt";
        private string path = @"D:\harun\studentFile.txt";
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (!File.Exists(path))
            {
                File.Create(path);
            }
            FileStream aFileStream=new FileStream(path,FileMode.Append);
            StreamWriter sr=new StreamWriter(aFileStream);
            sr.Write(nameTextBox.Text);
            sr.WriteLine();
            nameTextBox.Text = "";
            sr.Close();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            if(File.Exists(path))
            {
                FileStream aStream=new FileStream(path,FileMode.Open);
                StreamReader sr=new StreamReader(aStream);
                while (!sr.EndOfStream)
                {
                    string aline = sr.ReadLine();
                    studentListBox.Items.Add(aline);
                }
                sr.Close();
            }
        }
    }
}

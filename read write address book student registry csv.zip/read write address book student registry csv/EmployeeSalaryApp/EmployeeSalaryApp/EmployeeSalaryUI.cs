﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CSVLib;

namespace EmployeeSalaryApp
{
    public partial class EmployeeSalaryUI : Form
    {
        private string fileLocation = @"employeeSalary.csv";
        public EmployeeSalaryUI()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
           FileStream aStream=new FileStream(fileLocation,FileMode.Append);
           CsvFileWriter aWriter = new CsvFileWriter(aStream);
           List<string> employeeList = new List<string>();

           employeeList.Add(nameTextBox.Text);
           employeeList.Add(idTextBox.Text);
           employeeList.Add(salaryAmountTextBox.Text);
           aWriter.WriteRow(employeeList);
           //nameTextBox.Text = "";
           //idTextBox.Text = "";
           //salaryAmountTextBox.Text = "";
               
           aStream.Close();
            

        }

        private void showButton_Click(object sender, EventArgs e)
        {
            FileStream aStream = new FileStream(fileLocation, FileMode.Open);
            CsvFileReader aReader=new CsvFileReader(aStream);
            List<string> emplyeeList=new List<string>();
            double total = 0;
            showAllListBox.Items.Clear();
            while (aReader.ReadRow(emplyeeList))
            
            {
                string name = emplyeeList[0];
                string id = emplyeeList[1];
                string salary = emplyeeList[2];
                showAllListBox.Items.Add(name+" ,"+id+", "+salary);
                double salaryamoutn = Convert.ToDouble(salary);
                total += salaryamoutn;



            }

            aStream.Close();
            totalTextBox.Text = total.ToString();

        }
    }
}
